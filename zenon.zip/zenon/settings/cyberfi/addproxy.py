import json
import os
import platform
import re  # Mengimpor ekspresi reguler untuk validasi
from zenonfox import banner

DATA_FILE_PATH = os.path.join('zenonPY', 'cyberfi', 'data-proxy.json')

def clear_terminal():
    """Bersihkan layar terminal."""
    if platform.system() == "Windows":
        os.system('cls')  # Untuk Windows
    else:
        os.system('clear')  # Untuk Mac/Linux

def create_banner():
    """Buat banner untuk skrip proxy."""
    return banner.create_banner(game_name="Cyber finance | Proxy")

def load_data():
    """Muat data dari file JSON."""
    if os.path.exists(DATA_FILE_PATH):
        with open(DATA_FILE_PATH, 'r') as file:
            return json.load(file)
    return {"accounts": []}

def save_data(data):
    """Simpan data ke file JSON."""
    with open(DATA_FILE_PATH, 'w') as file:
        json.dump(data, file, indent=4)

def is_valid_acc_info(acc_info):
    """Validasi informasi akun."""
    return (acc_info.startswith("query_id=") or acc_info.startswith("user=")) and \
           ("user=" in acc_info or "query_id=" in acc_info)

def is_valid_proxy_info(proxy_info):
    """Validasi informasi proxy."""
    proxy_regex = r'http://[a-zA-Z0-9._%+-]+:[a-zA-Z0-9._%+-]+@[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+:[0-9]+'
    return re.match(proxy_regex, proxy_info) is not None

def fill_empty_entries(data):
    """Mengisi entri yang kosong dalam data."""
    for account in data["accounts"]:
        if not account.get("acc_info"):
            account["acc_info"] = input("input your (Query_id | User) : ")
        if not account.get("proxy_info"):
            account["proxy_info"] = input("input your proxy : ")

def add_proxy():
    """Fungsi untuk menambahkan proxy baru."""
    clear_terminal()  # Bersihkan terminal sebelum mengambil input
    print(create_banner())  # Tampilkan banner
    
    # Muat data yang ada
    data = load_data()

    # Hapus entri yang kosong
    original_length = len(data["accounts"])
    data["accounts"] = [account for account in data["accounts"] if account.get("acc_info") and account.get("proxy_info")]
    
    if len(data["accounts"]) < original_length:
        save_data(data)  # Simpan data setelah menghapus entri kosong
        print("The entry has been updated....")

    # Jika tidak ada akun, minta pengguna untuk menambahkan yang baru
    if not data["accounts"]:
        print("No accounts found. Please add a new account.")
    
    while True:
        acc_info = input("(enter to cancel)\ninput (Query_id | User) : ")
        if acc_info.strip() == "":
            print("The proxy adding process was cancelled.")
            return  # Keluar dari fungsi jika input kosong
        if not is_valid_acc_info(acc_info):
            print("[Error] ]input 'query_id=' 'user='. correctly (Please try again.)")
            continue
        
        proxy_info = input("(enter to cancel)\ninput (Proxy) :  ")
        if proxy_info.strip() == "":
            print("The proxy adding process was cancelled.")
            return  # Keluar dari fungsi jika input kosong
        if not is_valid_proxy_info(proxy_info):
            print("Proxy information must be in the format http://user:pass@ip:port. Please try again.")
            continue
        
        # Periksa duplikasi
        for account in data["accounts"]:
            if account["acc_info"] == acc_info:
                print("Account information already exists. Please enter different account information.")
                break
            if account["proxy_info"] == proxy_info:
                print("Proxy information already exists. Please enter different proxy information.")
                break
        else:
            # Jika semua validasi berhasil dan tidak ada duplikasi
            new_entry = {
                "acc_info": acc_info,
                "proxy_info": proxy_info
            }
            data["accounts"].append(new_entry)
            save_data(data)
            print("Proxy successfully added!")
            input("Press (Enter) to return to the menu...")  # Tunggu pengguna untuk mengakui
            return  # Kembali ke menu
            
            
def view_proxies():
    """Fungsi untuk melihat semua proxy."""
    clear_terminal()  # Bersihkan terminal sebelum menampilkan proxy
    print(create_banner())  # Tampilkan banner
    data = load_data()
    if data["accounts"]:
        for i, account in enumerate(data["accounts"], start=1):
            if 'acc_info' in account and 'proxy_info' in account:
                print(f"account {i}:")
                print(f"  Akun: {account['acc_info']}")
                print(f"  Proxy: {account['proxy_info']}")
                print()
            else:
                print(f"account {i} do not have complete information.")
    else:
        print("No proxy found.")
    input("Press (Enter) to return to the menu...")  # Tunggu pengguna untuk mengakui
    
def delete_proxy():
    """Fungsi untuk menghapus proxy."""
    clear_terminal()  # Bersihkan terminal sebelum menghapus proxy
    print(create_banner())  # Tampilkan banner
    data = load_data()
    if data["accounts"]:
        for i, account in enumerate(data["accounts"], start=1):
            print(f"account {i}:")
            print(f"  Akun: {account['acc_info']}")
            print(f"  Proxy: {account['proxy_info']}")
            print()
        while True:
            proxy_number = input("Enter the proxy number you want to delete ( or '0' to cancel): ")
            if proxy_number.lower() == "0":
                print("The proxy deletion process was cancelled.")
                return  # Keluar dari fungsi jika input 'cancel'
            try:
                proxy_number = int(proxy_number)
                if 1 <= proxy_number <= len(data["accounts"]):
                    del data["accounts"][proxy_number - 1]
                    save_data(data)
                    print("Proxy successfully deleted!")
                    input("Press Enter to return to the menu...")  # Tunggu pengguna untuk mengakui
                    return  # Kembali ke menu
                else:
                    print("Invalid proxy number. Please try again.")
            except ValueError:
                print("Input must be a number. Please try again.")
    else:
        print("No proxies found.")
    input("Press Enter to return to the menu...")  # Tunggu pengguna untuk mengakui

def main():
    """Fungsi utama untuk menjalankan skrip."""
    while True:
        clear_terminal()  # Bersihkan terminal sebelum menampilkan menu
        print(create_banner())  # Tampilkan banner
        print("Select")
        print("1. Add Proxy")
        print("2. View Proxy")
        print("3. delete Proxy")
        print("0. Back")
        choice = input("Pilih opsi: ")
        if choice == "1":
            add_proxy()
        elif choice == "2":
            view_proxies()
        elif choice == "3":
            delete_proxy()
        elif choice == "0":
            print("Thank you for using script!")
            break
        else:
            print("Invalid option. Please try again.")

if __name__ == "__main__":
    main()