import subprocess
import os
import sys
import shutil
import platform

# Bersihkan layar terminal
os.system('clear')

class Menu:
    def __init__(self):
        self.pilihan = {
            "1": "Cyber Finance",
            "2": "TONxDAO"
        }
        from zenonfox import banner
        self.banner = banner.create_banner(game_name="List Game")
        
    def tampilkan_menu(self):
        print(self.banner)  # Tampilkan banner
        print("(Game list) select to continue")
        for key, value in self.pilihan.items():
            print(f"{key}. {value}")

    def jalankan_pilihan(self):
        pilihan = input("Enter your choice: ")
        if pilihan in self.pilihan:
            if pilihan == "1":
                self.cyber_finance()
            elif pilihan == "2":
                self.dao()
        else:
            print("invalid selection try again!!.")

    def cyber_finance(self):
        print("Select Cyber Finance.")
        
        # Menjalankan file settings.py di direktori cyberfi
        file_path = "settings/cyberfi/settings.py"
        try:
            subprocess.run([sys.executable, file_path], check=True)
        except FileNotFoundError:
            print("[error] cyber finance file not found")
        except subprocess.CalledProcessError as e:
            print(f"script failed to start {e}")
        except Exception as e:
            print(f"There is an error: {e}")

    def dao(self):
        print("You choose DAO.")
        
        # Menjalankan file settings.py di direktori settings/Dao
        file_path = "settings/Dao/settings.py"
        try:
            subprocess.run([sys.executable, file_path], check=True)
        except FileNotFoundError:
            print("TONxDao file not found.")
        except subprocess.CalledProcessError as e:
            print(f"Script failed to run: {e}")
        except Exception as e:
            print(f"There is an error: {e}")

if __name__ == "__main__":
    menu = Menu()
    menu.tampilkan_menu()
    menu.jalankan_pilihan()