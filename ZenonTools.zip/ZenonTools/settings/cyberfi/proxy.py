import subprocess
import os
import platform
import sys
import time
import shutil
from zenonfox import banner

def clear_terminal():
    """Clear the terminal screen."""
    if platform.system() == "Windows":
        os.system('cls')  # For Windows
    else:
        os.system('clear')  # For Mac/Linux

def create_banner():
    """Create a banner for the proxy script."""
    return banner.create_banner(game_name="Cyber finance | Proxy Menu")

def edit_proxy_settings():
    """Function to run the addproxy.py script."""
    add_proxy_script = os.path.join('settings', 'cyberfi', 'addproxy.py')
    try:
        subprocess.run([sys.executable, add_proxy_script], check=True)
    except FileNotFoundError:
        print("File not found.")
    except subprocess.CalledProcessError:
        print("Failed to execute script")
    except Exception as e:
        print(f"There is an error: {e}")

def copy_file(src, dst):
    """Salin file dari src ke dst."""
    try:
        shutil.copy(src, dst)
        print("loading data to start.....")
    except Exception as e:
        print(f"Failed to copy data. {e}")

def install_requirements(requirements_file):
    """Instal dependensi dari requirements.txt tanpa menampilkan output."""
    print("Installing Data please wait...", flush=True)
    try:
        subprocess.run(
            [sys.executable, '-m', 'pip', 'install', '-r', requirements_file],
            check=True,
            stdout=subprocess.DEVNULL,  # Suppress output
            stderr=subprocess.DEVNULL,   # Suppress error messages
            text=True
        )
        print("Data successfully installed.")
    except subprocess.CalledProcessError:
        print("Failed to install Data.")

def check_requirements_installed(requirements_file):
    """Periksa apakah semua dependensi di requirements.txt telah terinstal."""
    with open(requirements_file, 'r') as f:
        requirements = f.readlines()
    
    for requirement in requirements:
        try:
            subprocess.run([sys.executable, '-m', 'pip', 'show', requirement.strip()], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except subprocess.CalledProcessError:
            return False
    return True

def start_game():
    """Fungsi untuk memulai permainan."""
    data_src = os.path.join('Data', 'cyberfinance.txt')
    data_dst = os.path.join('zenonPY', 'cyberfi', 'data.txt')
    requirements_file = os.path.join('zenonPY', 'cyberfi', 'requirements.txt')
    bot_script = os.path.join('zenonPY', 'cyberfi', 'bot-proxy.py')  # Ensure this path is correct

    print("loading...", flush=True)
    copy_file(data_src, data_dst)

    if not check_requirements_installed(requirements_file):
        install_requirements(requirements_file)

    # Try to run the bot_script
    try:
        subprocess.run([sys.executable, bot_script], check=True)
    except FileNotFoundError:
        print("Bot script not found.")
    except subprocess.CalledProcessError as e:
        print(f"Failed to run bot script: {e}")
    except Exception as e:
        print(f"An error occurred while running the bot: {e}")

    print("Loading complete!")

def main():
    """Main function to display the menu."""
    while True:
        clear_terminal()  # Clear terminal before displaying menu
        print(create_banner())
        print("Select")
        print("1. Edit Proxy Settings")
        print("2. Start Game")
        print("3. Back")
        choice = input("Choose an option: ")

        if choice == "1":
            edit_proxy_settings()
        elif choice == "2":
            start_game()  # Only run bot-proxy.py
        elif choice == "3":
            clear_terminal()  # Clear terminal before exiting
            print(create_banner())  # Display banner before exit
            print("\nExiting...")  # Show exit message
            time.sleep(1)  # Wait 1 second before exiting
            sys.exit()  # Exit the program
        else:
            print("Invalid option. Please choose a valid option.")

if __name__ == "__main__":
    main()