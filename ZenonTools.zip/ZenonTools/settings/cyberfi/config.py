import json
import os
import subprocess
import platform
import time
from zenonfox import banner
from colorama import init, Fore

# Inisialisasi colorama
init(autoreset=True)

def create_banner():
    """Buat banner untuk permainan."""
    return banner.create_banner(game_name="CyberFinance | config")

def load_config():
    root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    config_path = os.path.join(root_dir, 'zenonpy', 'cyberfi', 'config.json')

    try:
        with open(config_path, 'r') as file:
            config = json.load(file)
            return config
    except FileNotFoundError:
        print("Config file not found.")
        return None
    except json.JSONDecodeError:
        print("Error parsing Config")
        return None

def save_config(config):
    root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    config_path = os.path.join(root_dir, 'zenonpy', 'cyberfi', 'config.json')

    try:
        with open(config_path, 'w') as file:
            json.dump(config, file, indent=4)
    except Exception as e:
        print(f"Error saving config file: {e}")

def clear_screen():
    os.system('cls' if platform.system() == 'Windows' else 'clear')

def print_choices(config):
    if config:
        print("Select")
        for index, (key, value) in enumerate(config.items(), start=1):
            color = Fore.BLUE if value == "true" else Fore.RED
            print(f"{index}. {key} (Status: {color}{value}{Fore.RESET})")
    else:
        print("There are no options to display.")

def update_choice(config, index):
    if 0 < index <= len(config):
        key = list(config.keys())[index - 1]
        current_status = config[key]
        new_status = "false" if current_status == "true" else "true"
        config[key] = new_status
        print(f"Status '{key}' has been changed to {new_status}.")
        return True
    else:
        return False

def loading_animation(message, duration):
    """Menampilkan animasi loading dengan pesan."""
    print(message, end="", flush=True)
    for _ in range(duration):
        time.sleep(1)  # Tunggu selama 1 detik
        print(".", end="", flush=True)  # Tambahkan titik
    print()  # Pindah ke baris baru setelah selesai

def main():
    banner_text = create_banner()
    config = load_config()
    
    clear_screen()
    print(banner_text)
    
    while True:
        print_choices(config)
        choice_input = input("Select number to change or (enter) to exit.")

        if choice_input == "":
            clear_screen()
            loading_animation("Loading", 3)  # Animasi loading selama 3 detik
            subprocess.run(["python", os.path.join('settings', 'cyberfi', 'settings.py')])
            clear_screen()
            print(banner_text)
            continue
        
        try:
            choice_index = int(choice_input)
            if update_choice(config, choice_index):
                clear_screen()
                print(banner_text)
                save_config(config)
            else:
                clear_screen()
                print(banner_text)
                print("Invalid selection. Please try again..")
                input("Press enter to continue...")
        except ValueError:
            clear_screen()
            print(banner_text)
            print("Please enter a valid number. Please try again.")
            input("Press enter to continue...")

if __name__ == "__main__":
    main()