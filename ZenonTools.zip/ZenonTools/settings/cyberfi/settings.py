import subprocess
import sys
import os
import shutil
from zenonfox import banner

def create_banner():
    """Buat banner untuk permainan."""
    return banner.create_banner(game_name="Cyberfinance / Settings")

def clear_terminal():
    """Bersihkan layar terminal."""
    os.system('cls' if os.name == 'nt' else 'clear')

def run_config_script():
    """Jalankan skrip konfigurasi."""
    file_path = os.path.join(os.path.dirname(__file__), 'config.py')
    try:
        subprocess.run([sys.executable, file_path], check=True)
    except FileNotFoundError:
        print("File not found.")
    except subprocess.CalledProcessError as e:
        print(f"Script failed to run: {e}")
    except Exception as e:
        print(f"There is an error: {e}")

def edit_query():
    """Edit file data.txt."""
    file_path = os.path.join('data', 'cyberfinance.txt')
    try:
        subprocess.run(['nano', file_path])  # Buka data.txt dengan nano
    except FileNotFoundError:
        print("data file not found.")
    except Exception as e:
        print(f"An error occurred while opening the data: {e}")
    finally:
        clear_terminal()  # Clear terminal
        print(create_banner())  # Print banner
        print_menu()  # Print menu again

def print_menu():
    """Print the main menu."""
    print("Select")
    print("1. Edit Config")
    print("2. Edit query")
    print("3. start game without proxy")
    print("4. start game with proxy")
    print("5. back")

def copy_file(src, dst):
    """Salin file dari src ke dst."""
    try:
        shutil.copy(src, dst)
        print("File copied successfully.")
    except Exception as e:
        print(f"Failed to copy file: {e}")

def install_requirements(requirements_file):
    """Instal dependensi dari requirements.txt tanpa menampilkan output."""
    print("Installing data please wait...", flush=True)
    try:
        subprocess.run(
            [sys.executable, '-m', 'pip', 'install', '-r', requirements_file],
            check=True,
            stdout=subprocess.DEVNULL,  # Suppress output
            stderr=subprocess.DEVNULL,   # Suppress error messages
            text=True
        )
        print("Data successfully installed.")
    except subprocess.CalledProcessError:
        print("Failed to install data.")

def check_requirements_installed(requirements_file):
    """Periksa apakah semua dependensi di requirements.txt telah terinstal."""
    with open(requirements_file, 'r') as f:
        requirements = f.readlines()
    
    for requirement in requirements:
        try:
            subprocess.run(
                [sys.executable, '-m', 'pip', 'show', requirement.strip()],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
        except subprocess.CalledProcessError:
            return False
    return True

def start_game():
    """Fungsi untuk memulai permainan."""
    data_src = os.path.join('Data', 'cyberfinance.txt')
    data_dst = os.path.join('zenonPY', 'cyberfi', 'data.txt')
    requirements_file = os.path.join('zenonPY', 'cyberfi', 'requirements.txt')
    bot_script = os.path.join('zenonPY', 'cyberfi', 'bot.py')

    print("Loading.....", flush=True)
    copy_file(data_src, data_dst)

    if not check_requirements_installed(requirements_file):
        install_requirements(requirements_file)

    try:
        subprocess.run([sys.executable, bot_script], check=True)
    except FileNotFoundError:
        print("Bot script not found.")
    except subprocess.CalledProcessError:
        print("Failed to execute bot script.")
    except Exception as e:
        print(f"There is an error: {e}")

    print("Loading complete!")

def start_game_with_proxy():
    """Fungsi untuk memulai skrip proxy."""
    proxy_script = os.path.join('settings', 'cyberfi', 'proxy.py')

    print("Starting the proxy menu...", flush=True)

    try:
        subprocess.run([sys.executable, proxy_script], check=True)
    except FileNotFoundError:
        print("Proxy menu script not found.")
    except subprocess.CalledProcessError:
        print("Failed to run proxy script.")
    except Exception as e:
        print(f"There is an error: {e}")

    print("The proxy menu script has started!")

def run_main_py():
    """Fungsi untuk menjalankan main.py."""
    main_py_script = os.path.join('main.py')

    try:
        subprocess.run([sys.executable , main_py_script], check=True)
    except FileNotFoundError:
        print("menu game not found")
    except subprocess.CalledProcessError:
        print("Failed to run game")
    except Exception as e:
        print(f"There is an error: {e}")

def main():
    """Fungsi utama."""
    while True:
        clear_terminal()  # Clear terminal
        print(create_banner())
        print_menu()

        choice = input("Pilih opsi: ")

        if choice == "1":
            run_config_script()
        elif choice == "2":
            edit_query()
        elif choice == "3":
            start_game()
        elif choice == "4":
            start_game_with_proxy()
        elif choice == "5":
            try:
                # Menjalankan main.py dari direktori folderutama
                subprocess.run([sys.executable, 'main.py'], check=True)
                break  # Keluar dari loop setelah menjalankan main.py
            except FileNotFoundError:
                print("Game file not found in the specified path.")
            except subprocess.CalledProcessError:
                print("Failed to run Game")
        else:
            print("Invalid option. Please try again.")
        
        clear_terminal()  # Clear terminal after each choice

if __name__ == "__main__":
    main()