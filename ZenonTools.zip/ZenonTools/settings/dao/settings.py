import subprocess
import sys
import os
import shutil
from zenonfox import banner

def create_banner():
    """Buat banner untuk permainan."""
    return banner.create_banner(game_name="TONxDAO | Settings")

def clear_terminal():
    """Bersihkan layar terminal."""
    os.system('cls' if os.name == 'nt' else 'clear')

def edit_config():
    """Jalankan file config.py."""
    config_file_path = os.path.join(os.path.dirname(__file__), 'config.py')  # Path to config.py
    try:
        subprocess.run([sys.executable, config_file_path])  # Jalankan config.py dengan Python
    except FileNotFoundError:
        print("[TONxDAO] File not found.")
    except Exception as e:
        print(f"An error occurred while executing the file: {e}")
    finally:
        clear_terminal()  # Bersihkan terminal
        print(create_banner())  # Cetak banner
        print_menu()  # Cetak menu lagi
        
def edit_query():
    """Edit file data.txt."""
    file_path = os.path.join('data', 'dao.txt')  # Changed to dao.txt
    try:
        subprocess.run(['nano', file_path])  # Open dao.txt with nano
    except FileNotFoundError:
        print("[TONxDAO] DATA file not found ")  # Updated error message
    except Exception as e:
        print(f"[TONxDAO] An error occurred while opening the file: {e}")
    finally:
        clear_terminal()  # Clear terminal
        print(create_banner())  # Print banner
        print_menu()  # Print menu again

def print_menu():
    """Print the main menu."""
    print("Select")
    print("1. Settings Config")
    print("2. add query")
    print("3. start game")
    print("4. Back")

def copy_file(src, dst):
    """Salin file dari src ke dst."""
    try:
        shutil.copy(src, dst)
        print("[TONxDAO] Loading All Data.....")
    except Exception as e:
        print(f"[TONxDAO] loading failed {e}")

def install_requirements(requirements_file):
    """Instal dependensi dari requirements.txt tanpa menampilkan output."""
    print("[TONxDAO] Data has not been installed. Installation will begin.", flush=True)
    try:
        subprocess.run(
            [sys.executable, '-m', 'pip', 'install', '-r', requirements_file],
            check=True,
            stdout=subprocess.DEVNULL,  # Suppress output
            stderr=subprocess.DEVNULL,   # Suppress error messages
            text=True
        )
        print("[TONxDAO] Data successfully installed.")
    except subprocess.CalledProcessError:
        print("[TONxDAO] Failed to install Data.")

def check_requirements_installed(requirements_file):
    """Periksa apakah semua dependensi di requirements.txt telah terinstal."""
    with open(requirements_file, 'r') as f:
        requirements = f.readlines()
    
    for requirement in requirements:
        try:
            subprocess.run(
                [sys.executable, '-m', 'pip', 'show', requirement.strip()],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
        except subprocess.CalledProcessError:
            return False
    return True

def start_game():
    """Fungsi untuk memulai permainan."""
    data_src = os.path.join('Data', 'dao.txt')  # Changed to dao.txt
    data_dst = os.path.join('zenonPY', 'Dao', 'data.txt')  # Changed folder name to Dao
    requirements_file = os.path.join('zenonPY', 'Dao', 'requirements.txt')  # Changed folder name to Dao
    bot_script = os.path.join('zenonPY', 'Dao', 'bot.py')  # Changed folder name to Dao

    print("[TONxDAO] Loading.....", flush=True)
    copy_file(data_src, data_dst)

    if not check_requirements_installed(requirements_file):
        install_requirements(requirements_file)

    try:
        subprocess.run([sys.executable, bot_script], check=True)
    except FileNotFoundError:
        print("[TONxDAO] Bot script not found.")
    except subprocess.CalledProcessError:
        print("[TONxDAO] Failed to run bot script.")
    except Exception as e:
        print(f"[TONxDAO] There is an error: {e}")

    print("[TONxDAO] wait while data is loading...")

if __name__ == "__main__":
    clear_terminal()
    print(create_banner())
    print_menu()

    while True:
        choice = input("Select: ")
        if choice == "1":
            edit_config()  # Edit Config option
        elif choice == "2":
            edit_query()  # Edit query option
        elif choice == "3":
            start_game()  # Start game option
        elif choice == "4":
            # Kembali ke main.py
            subprocess.run([sys.executable, 'main.py'])  # Run main.py
            break  # Exit the current script
        else:
            print("[TONxDAO] Invalid selection. Please try again..")